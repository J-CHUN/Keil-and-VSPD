#ifndef __DELAY_H__
#define __DELAY_H__

void DelayUs2x(unsigned char t);
void DelayMs(unsigned int t);

#endif
